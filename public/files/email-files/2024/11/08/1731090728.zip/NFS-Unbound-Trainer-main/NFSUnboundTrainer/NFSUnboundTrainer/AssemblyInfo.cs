using System.Diagnostics.CodeAnalysis;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows;

[assembly: AssemblyCopyright("Copyright ©  2024")]
[assembly: SuppressMessage("Usage", "CA1416:This call site is reachable on all platforms")]

[assembly: ComVisible(false)]
[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]