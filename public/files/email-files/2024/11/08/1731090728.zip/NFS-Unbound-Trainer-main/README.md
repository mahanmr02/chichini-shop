# NFS Unbound Trainer

## Overview

Simple trainer made in like 3 days because of boredom.

Enjoy I guess?

## Features

### Self/Vehicle

- **Freeze AI**
- **Unlimited NOS**
- **Unlimited Vehicle Durability**
- **Police Reinforcements Time Freeze**
- **Cannot Be Arrested**
- **Freeze Lap Time/Drift Zone Timer**
- **Velocity**
- **Brake Hack**
- **Heat Level**

### Unlocks

- **Credits/Money**
- **Free Vehicles**
- **Free Custom Vehicles**

## Screenshots

![image](https://github.com/szaaamerik/NFS-Unbound-Trainer/assets/126014478/a2509624-fd05-4d90-9527-694fdcadf8ef)

## License

This project is licensed under the [GPL-3.0 License](LICENSE).

## Support

For any issues, please open an [issue](https://github.com/szaaamerik/NFS-Unbound-Trainer/issues).
